### 						*Crazy Question*

1-Iniciar el juego, realizando doble click izquierdo sobre el acceso directo al juego.

2-Abrir men� en la ventana QuestionView. 

3-Elegir nuevo jugador para comenzar un nuevo juego y nueva pregunta para agregar una nueva pregunta a la base de datos.

4-Si eligio *nueva pregunta*,para agregar una nueva pregunta. Hay que llenar el formulario con la pregunta realizada, las posibles respuestas y la respuesta correcta.

5-Si eligio *nuevo jugador*, para comenzar se debe colocar el nombre de identificacion en el juego. 

6-Luego seleccionar la dificultad, modificando el tiempo en la ventana, podemos darle el valor numerico y dar click en set. Por defecto el juego arranca con una dificultad de 100 s.
  se puede modificar este valor con la tecla *>>* para sumar un segundo mas por cada vez que se la presione o se puede modificar con la tecla *<<* para restar un segundo por cada vez 
  que se la presione. 

7-Cuando aparezca una nueva pregunta se pueden elegir entre responder o pasar la pregunta, la pregunta que se pasa o si la pregunta es incorrecta no se suman puntos.
  Adem�s si se te acaba el tiempo para responder la pregunta se toma como incorrecta.

