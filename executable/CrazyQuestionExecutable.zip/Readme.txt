Instrucciones:

1. Para poder iniciar el juego se necesita el archivo que esta adjunto junto 
con el acceso directo del juego, el archivo se llama "base.obj".

2. Iniciar el juego, realizando doble click izquierdo sobre el acceso directo al
juego QuestionTestDrive.

3. Abrir men� en la ventana QuestionView.

4. Elegir nuevo jugador para comenzar un nuevo juego y nueva pregunta para
 agregar una nueva pregunta a la base de datos.

5. Si eligio nueva pregunta,para agregar una nueva pregunta. Hay que llenar el
formulario con la pregunta realizada, las posibles respuestas y la respuesta 
correcta.

6. Si eligio nuevo jugador, para comenzar se debe colocar el nombre de
 identificacion en el juego.

7. Luego seleccionar la dificultad, modificando el tiempo en la ventana, podemos
darle el valor numerico y dar click en set. Por defecto el juego arranca con una 
dificultad de 100 s. se puede modificar este valor con la tecla >> para sumar un
segundo mas por cada vez que se la presione o se puede modificar con la tecla <<
para restar un segundo por cada vez que se la presione.

8. Cuando aparezca una nueva pregunta se pueden elegir entre responder o pasar
la pregunta, la pregunta que se pasa o si la pregunta es incorrecta, no se 
suman puntos.

